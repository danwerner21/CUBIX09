/*
 * Calculate maximum of two argument values
 *
 * ?COPY.TXT 1988-2005 Dave Dunfield
 * **See COPY.TXT**.
 */
int max(a, b)
    int a, b;
{
    return (a > b) ? a : b;
}
