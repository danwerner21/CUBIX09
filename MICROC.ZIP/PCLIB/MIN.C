/*
 * Calculate minimum of two argument values
 *
 * ?COPY.TXT 1988-2005 Dave Dunfield
 * **See COPY.TXT**.
 */
int min(a, b)
    int a, b;
{
    return (a < b) ? a : b;
}
