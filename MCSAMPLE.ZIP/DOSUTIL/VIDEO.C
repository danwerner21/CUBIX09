/*
 * Quick and Dirty utility to dump video color attributes.
 *
 * ?COPY.TXT 1993-2003 Dave Dunfield
 * **See COPY.TXT**.
 *
 * Permission granted to use for personal (non-commercial) use only.
 *
 * Compile command: cc video -fop
 */
#include <stdio.h>
#include <window.h>
main()
{
    int f, b;
    wopen(0, 0, 80, 24, WSAVE|WCOPEN|NORMAL);
    wcursor_off();
    wgotoxy(30, 0);
    *W_OPEN = REVERSE;
    wputs(" VIDEO ATTRIBUTES ");
    for(b = 0; b < 16; ++b)
        for(f=0; f < 16; ++f) {
            wgotoxy(b*5, f+5);
            *W_OPEN = (b << 4) + f;
            wprintf("%02x", (b << 4) + f); }
    wgetc();
    wclose();
}
