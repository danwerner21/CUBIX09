/*
 * Here is a very simple MICRO-C program which takes as arguments a list
 * of filenames (which must be UPPERCASE), and exits with an ERROR CODE
 * of -1 (255) if any files exist in the current directory which are not
 * in that list. This compiles to a < 700 byte COM file.
 *
 * Compile with: cc anyfile -o
 */
main(argc, argv)
	int argc;
	char *argv[];
{
	int i, j;
	char filename[13];

	if(!find_first("*.*", 0, filename, &j, &j, &j, &j, &j))
		do {
			for(i=1; i < argc; ++i)
				if(!strcmp(argv[i], filename))
					break;
			if(i >= argc)
				exit(-1); }
		while(find_next(filename, &j, &j, &j, &j, &j));
/* Note: Falling out the bottom causes MICRO-C to return ERROR CODE=0 */
}
