/*
 * Print value of PI to 2400 places.
 *
 * Compile command: cc PI -fop
 */
#include <stdio.h>

#define	BLOCKS	600			// Number of blocks to process
#define	BRANGE	10000		// Maxumum range (4 digits)/block
#define	BSIZE	BLOCKS*14

extern unsigned Longreg[2];

main()
{
	unsigned a, b, c, e, g, i;
	unsigned d[2], f[BSIZE+1][2], l1[2];

	i=b=e=0;
	a=BRANGE;
	c=BSIZE;

	while(b < BSIZE)
		longset(f[b++], BRANGE/5);

	do {
		longset(d, 0);
		g = (b = c) * 2;
		for(;;) {
			longset(l1, a);
			longmul(l1, f[b]);
			longadd(d, l1);
			longset(l1, --g);
			longdiv(d, l1);
			longcpy(f[b], Longreg);
			--g;
			if(!--b)
				break;
			longset(l1, b);
			longmul(d, l1); }
		longset(l1, a);
		longdiv(d, l1);
		longset(l1, e);
		longadd(d, l1);
		e = *Longreg;
		printf("%04u", *d);
		if(!(++i%16))
			putc('\n', stdout); }
	while(c -= 14);
}
