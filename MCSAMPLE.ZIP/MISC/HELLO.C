/*
 * Standard 'C' demo... Say hello to the world
 *
 * Compile command: cc hello
 */
#include \mc\stdio.h

main()
{
	fputs("Hello world\n", stdout);
}
