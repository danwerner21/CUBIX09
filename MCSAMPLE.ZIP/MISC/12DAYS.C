/*
 * Generate the "12 days of christmas"
 *
 * Compile command: cc 12days -fop
 */
#include <stdio.h>

main()
{
	static char *phrases[] = {
		"a partridge in a pear tree.",
		"two turtle doves",
		"three french hens",
		"four calling birds",
		"FIVE GOLDEN RINGS;",
		"six geese a-laying,",
		"seven swans a-swimming",
		"eight maids a-milking",
		"nine ladies dancing",
		"ten lords a-leaping",
		"eleven pipers piping",
		"twelve drummers drumming" };
	static char *numbers[] = { "first", "second", "third", "fourth",
		"fifth", "sixth", "seventh", "eigth", "ninth", "tenth",
		"eleventh", "twelfth" };
	int i, column, day;

	for(day=0; day < 12; ++day) {
		printf("\nOn the %s day of christmas my true love gave to me:\n",
			numbers[day]);
		i = day;
		column = 0;
		do {
			printf("%s", phrases[i]);
			switch(i) {
				case 5 :
				case 4 : putc('\n', stdout); column = 0; break;
				case 1 : printf("\nand "); column = 0; break;
				default:
					if(i) putc(',', stdout);
					if(++column > 2) {
						column = 0;
						putc('\n', stdout); }
					else
						putc(' ', stdout); } }
		while(i--);
		putc('\n', stdout); }
}
