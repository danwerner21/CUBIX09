/*
 * The classic "Sieve of Eratosthenes" prime number program.
 * from BYTE, January 1983.
 *
 * Compile command: cc sieve -fop
 */
#include <stdio.h>
#define	TRUE	1
#define	FALSE	0
#define	SIZE	8190

char flags[SIZE+1];

main()
{
	int i, prime, k, count, iter;

	count = 0;
	for(i = 0; i <= SIZE; ++i)
		flags[i] = TRUE;
	for(i = 0; i <= SIZE; ++i) {
		if(flags[i]) {
			prime = i + 1 + 3;
			printf("\n%u", prime);
			for(k = i + prime; k <= SIZE; k += prime)
				flags[k] = FALSE;
			++count; } }

	printf("\n%u primes.", count);
}
