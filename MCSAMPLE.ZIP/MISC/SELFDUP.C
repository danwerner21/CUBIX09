/*
 * Self-replicating 'C' program
 *
 * Original author unknown.
 *
 * Compile command: CC selfdup -fop
 */
#include <stdio.h>
char c[]={"#include <stdio.h>%cchar c[]=%c%s%c;main(){printf(c,10,34,c,34);}"};
main(){printf(c,10,34,c,34);}
